﻿namespace Distributore_Numeri
{
    public class Distributore
    {
        private string _id;
        private string _ditta;
        private int _numPartenza;
        private int _numCorrente;
        private int _massimo;
        private Func<int, int> funzioneSuccessivo;
        private List<int> bigliettiPresi = new List<int>();
        private Distributore distributore;

        public Distributore(string id, string ditta, int numPartenza, int numCorrente, int massimo, Func<int, int> funzioneSuccessivo)
        {
            this.Id = id;
            this.Ditta = ditta;
            this.NumPartenza = numPartenza;
            this.NumCorrente = numCorrente;
            this.Massimo = massimo;
            this.funzioneSuccessivo = funzioneSuccessivo;
        }

        public Distributore(Distributore distributore) : this(distributore.Id, distributore.Ditta, distributore.NumPartenza, distributore.NumCorrente, distributore.Massimo, distributore.funzioneSuccessivo)
        {
            Id = distributore.Id;
            Ditta = distributore.Ditta;
            NumPartenza = distributore.NumPartenza;
            NumCorrente = distributore.NumCorrente;
            Massimo = distributore.Massimo;
            funzioneSuccessivo = distributore.funzioneSuccessivo;
        }

        public Distributore Clone()
        {
            return new Distributore(this);
        }

        public string Id
        {
            get
            {
                return _id;
            }
            private set
            {
                if (value != null)
                    _id = value;
                else
                    throw new Exception("Invalid Id");
            }
        }

        public string Ditta
        {
            get { return _ditta; }
            private set
            {
                if (value != null)
                    _id = value;
                else
                    throw new Exception("Invalid Ditta");
            }
        }

        public int NumPartenza
        {
            get { return _numPartenza; }
            private set { _numPartenza = value; }

        }

        public int NumCorrente
        {
            get { return _numCorrente; }
            private set { _numCorrente = value; }

        }

        public int Massimo
        {
            get { return _massimo; }
            private set { _massimo = value; }
        }





        public int NumeroCorrente()
        {
            return NumCorrente;
        }

        public int PrendiBiglietto()
        {
            int numero = NumCorrente;
            bigliettiPresi.Add(numero);
            NumCorrente = funzioneSuccessivo(NumCorrente);
            return numero;
        }

        public void Reset()
        {
            NumCorrente = NumPartenza;
            bigliettiPresi.Clear();
        }

        public bool VerificaSequenza(int[] sequenza)
        {
            int numCorrente = NumPartenza;
            foreach (int numero in sequenza)
            {
                if (numero != numCorrente)
                {
                    return false;
                }
                numCorrente = funzioneSuccessivo(numCorrente);
            }
            return true;
        }

        public int[] OttieniPresi()
        {
            return bigliettiPresi.ToArray();
        }



        public override string ToString()
        {
            return $"{this.Id};{this.Ditta};{this.NumPartenza};{this.NumCorrente};{this.Massimo};{this.funzioneSuccessivo}";
        }
    }
}