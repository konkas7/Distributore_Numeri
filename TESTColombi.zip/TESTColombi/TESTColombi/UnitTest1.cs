using Lotto;

namespace TESTColombi
{
    public class UnitTest1
    {
        


        [Fact]
        public void TestEstraiSingolo()
        {
            
            var lotto = new Lotto.Lotto("id1", "01/01/2021");

            
            var estratto = lotto.EstraiSingolo();

            
            Assert.True(estratto >= 1 && estratto <= 90);
            Assert.Contains(estratto, lotto.NumeriEstratti);
        }

        [Fact]
        public void TestEstraiCinque()
        {
            
            var lotto = new Lotto.Lotto("id1", "01/01/2021");

            
            var estratti = lotto.EstraiCinque();

            
            Assert.Equal(5, estratti.Length);
            Assert.All(estratti, e => Assert.True(e >= 1 && e <= 90));
            Assert.All(estratti, e => Assert.Contains(e, lotto.NumeriEstratti));
        }

        [Fact]
        public void TestClone()
        {
            
            var lotto = new Lotto.Lotto("id1", "01/01/2021");
            lotto.EstraiSingolo();

            
            var lottoClone = lotto.Clone();

            
            Assert.Equal(lotto.ID, lottoClone.ID);
            Assert.Equal(lotto.DataFabb, lottoClone.DataFabb);
            Assert.Equal(lotto.NumeriEstratti, lottoClone.NumeriEstratti);
        }

        [Fact]
        public void TestEquals()
        {
            
            var lotto1 = new Lotto.Lotto("id1", "01/01/2021");
            var lotto2 = new Lotto.Lotto("id1", "01/01/2022");
            var lotto3 = new Lotto.Lotto("id2", "01/01/2022");

            
            Assert.True(lotto1.Equals(lotto2));
            Assert.False(lotto1.Equals(lotto3));
        }

        [Fact]
        public void ResetTest()
        {
            
            Lotto.Lotto lotto = new Lotto.Lotto("123", "01/01/2022");
            lotto.EstraiSingolo();
            lotto.EstraiSingolo();

            
            lotto.Reset();

            
            Assert.Empty(lotto.NumeriEstratti);
        }
    }
}